package sp.senai.br.calcularidadecores;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    EditText txtNome, txtAno;
    TextView txtResultado;
    Button btnCalcula;
    ConstraintLayout tela;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.tela), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        txtNome = findViewById(R.id.txtNome);
        txtAno = findViewById(R.id.txtAno);
        txtResultado = findViewById(R.id.txtResultado);
        btnCalcula = findViewById(R.id.btnCalcula);
        tela = findViewById(R.id.tela);

        btnCalcula.setEnabled(false);

        txtAno.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!txtNome.getText().toString().equals("")
                && txtAno.getText().toString().length() == 4){
                    btnCalcula.setEnabled(true);
                } else {
                    btnCalcula.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        txtNome.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if(!txtNome.getText().toString().equals("")
                        && txtAno.getText().toString().length() == 4){
                    btnCalcula.setEnabled(true);
                } else {
                    btnCalcula.setEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    public void Calcular(View v){
        Calendar cal = Calendar.getInstance();
        int anoAtual = cal.get(Calendar.YEAR);

        int anoNasc = Integer.valueOf(txtAno.getText().toString());

        int idade = anoAtual - anoNasc;

        txtResultado.setText(txtNome.getText().toString()+ " sua idade é: "+ idade + " anos");

        if(idade<=5){
            tela.setBackgroundColor(Color.parseColor("#FACADA"));
            txtResultado.setTextColor(Color.parseColor("#000000"));
        } else if (idade<=11){
            tela.setBackgroundColor(Color.parseColor("#000000"));
            txtResultado.setTextColor(Color.parseColor("#FFFFFF"));
        } else {
            tela.setBackgroundColor(Color.parseColor("#FFFFFF"));
            txtResultado.setTextColor(Color.parseColor("#000000"));
        }
    }


}