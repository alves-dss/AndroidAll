package sp.senai.br.calculadora;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText txtNum1, txtNum2;
    TextView txtResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.txtNum1), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txtNum1 = findViewById(R.id.txtNum1);
        txtNum2 = findViewById(R.id.txtNum2);
        txtResult = findViewById(R.id.txtResult);
    }

    public void executarOperacao(View v){

        float resultado = 0;
        float num1 = Float.valueOf(txtNum1.getText().toString());
        float num2 = Float.valueOf(txtNum2.getText().toString());

        if(v.getId() == R.id.bMais){
            resultado = num1 + num2;
        }else if(v.getId() == R.id.bMenos){
            resultado = num1 - num2;
        }else if(v.getId() == R.id.bMult){
            resultado = num1 * num2;
        }else if(v.getId() == R.id.bDiv){
            resultado = num1 / num2;
        }

        txtResult.setText(String.valueOf(resultado));
    }

    public void Limpar(View v){
        txtResult.setText("Resultado");
        txtNum1.setText("");
        txtNum2.setText("");
    }
}