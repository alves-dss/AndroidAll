package sp.senai.br.advinhatodos;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText txtNumero;
    TextView txtResposta, txtTentativasAnteriores;
    String textoTentativa;
    int sorteado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        txtNumero = findViewById(R.id.txtNumero);
        txtResposta = findViewById(R.id.txtResposta);
        txtTentativasAnteriores = findViewById(R.id.txtTentativasAnteriores);

        sorteado = (int) (Math.random() * 100)+1;
        textoTentativa = "Tentativas Anteriores:  ";
    }

    public void adivinhar(View v){
        int numero = Integer.parseInt(txtNumero.getText().toString());

        if(numero < sorteado){
            txtResposta.setText("Seu numero está abaixo do sorteado");
        }if(numero > sorteado){
            txtResposta.setText("Seu numero está acima do sorteado");
        }else{
            txtResposta.setText("Acertou!!");
        }

        textoTentativa += numero + ",";
        txtTentativasAnteriores.setText(textoTentativa.substring(0, txtTentativasAnteriores.getText().length() -2));
    }
}