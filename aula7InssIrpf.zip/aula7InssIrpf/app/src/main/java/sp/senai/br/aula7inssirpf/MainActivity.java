package sp.senai.br.aula7inssirpf;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText txtSalarioBruto, txtNumeroDeFilhos;

    TextView txtINSS, txtIRPF, txtSalarioLiquido;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txtSalarioBruto = findViewById(R.id.txtSalarioBruto);
        txtNumeroDeFilhos = findViewById(R.id.txtNumeroDeFilhos);
        txtINSS = findViewById(R.id.txtINSS);
        txtIRPF = findViewById(R.id.txtIRPF);
        txtSalarioLiquido = findViewById(R.id.txtSalarioLiquido);
    }

    public void calcular(View v){
        float salarioBruto = Float.valueOf(txtSalarioBruto.getText().toString());
        float inss = 0;

        if(salarioBruto > 1621){
            inss = salarioBruto * 0.75f;
        }else if(salarioBruto > 2902.84){
            inss = salarioBruto * 0.090f;
        }else if(salarioBruto > 4357.27){
            inss = salarioBruto * 0.120f;
        }else{
            inss = salarioBruto * 0.160f;
        }

        float maximoINSS = 8475.55f * 0.140f;
        if(inss > maximoINSS){
            inss = maximoINSS;
        }

        float NumeroDeFilhos = Float.valueOf(txtNumeroDeFilhos.getText().toString());
        float descontoINSS = NumeroDeFilhos * 67.54f;

        inss = inss - descontoINSS;

        if(inss < 0){
            inss = 0;
        }

        txtINSS.setText("INSS: "+ inss);

        float irpf = 0;

        if(salarioBruto > 5000){
            irpf = (salarioBruto * 0.275f) - 908.73f;
        }

        txtIRPF.setText("IRPF: "+ irpf);

        float salarioLiquido = salarioBruto - inss - irpf;
        txtSalarioLiquido.setText("Salario liquido: "+salarioLiquido);
    }
}